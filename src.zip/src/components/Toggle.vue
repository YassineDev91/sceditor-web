<template>
    <label
      for="AcceptConditions"
      class="relative inline-block h-8 w-14 cursor-pointer rounded-full bg-gray-300 transition [-webkit-tap-highlight-color:_transparent] has-[:checked]:bg-green-500"
    >
      <input type="checkbox" id="AcceptConditions" class="peer sr-only" />
    
      <span
        class="absolute inset-y-0 start-0 m-1 size-6 rounded-full bg-white transition-all peer-checked:start-6"
      ></span>
    </label>
  </template>