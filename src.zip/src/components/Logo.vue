<template>
    <h1 class=" blakc:text-slate-200 text-slate-200 text-xs">
        SCEditor
    </h1>
</template>