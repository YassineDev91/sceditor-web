<template>
    <v-group :config="groupConfig">
        <v-rect :config="rectConfig"></v-rect>
        <v-text :config="textConfig" />

        <StatementRenderer :statement="statement" />
        <!-- <v-text :config="contentConfig" v-for="expression in props.statement" :text="expression.params.type" /> -->

    </v-group>
</template>
<script setup>
import { onMounted, ref } from "vue";

onMounted(() => {
    console.log();

})

const props = defineProps({
    x: Number,
    y: Number,
    type: String,
    statement: Object
});
const rectConfig = ref({
    x: props.x,
    y: props.y,
    width: 200,
    height: 130,
    stroke: 'black',
    cornerRadius: 5,
    fill: "#E7F4FE",
    stroke: "#84B2E9"
})
const textConfig = ref({
    x: rectConfig.value.x + 45,
    y: rectConfig.value.y + 17,
    text: "LoopStatement",
    fontSize: 15,
})

const groupConfig = ref({
    x: props.x,
    y: props.y,
    draggable: true,
})

const contentConfig = ref({
    x: rectConfig.value.x + 3,
    y: rectConfig.value.y + 10,
    fontSize: 12,
})

</script>

<style></style>