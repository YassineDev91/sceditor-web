
<template>
  <div>
    <h2 class="text-md font-bold mb-2">Statement Properties</h2>
    <div v-if="element && element.type === 'AssignmentStatement'">
      <label class="block text-sm">Left</label>
      <input v-model="element.expressions.left.base" class="input-field" />
      <label class="block text-sm mt-2">Right</label>
      <input v-model="element.expressions.right.base" class="input-field" />
    </div>
    <div v-else>
      <p class="text-gray-500 text-sm">No editable fields for this statement type yet.</p>
    </div>
  </div>
</template>

<script setup>
defineProps({ element: Object });
</script>

<style scoped>
.input-field {
  @apply border rounded px-2 py-1 w-full text-sm;
}
</style>
