<script setup>
import { computed } from 'vue'
const props = defineProps({ element: Object })

// Create a computed ref that links to the element's name
const name = computed({
  get: () => props.element?.name ?? '',
  set: (val) => {
    if (props.element) props.element.name = val
  }
})
</script>

<template>
    {{ props.element }}
  <div class="flex flex-col gap-2">
    <label class="text-xs">Name</label>
    <input
      v-model="name"
      type="text"
      class="border rounded p-1 text-sm text-gray-700"
      placeholder="Enter name"
    />
  </div>
</template>