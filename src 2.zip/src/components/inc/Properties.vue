<template>
  <div class="py-4">
    <h2 v-if="element" class="font-semibold text-lg mb-4">Edit {{ element.type }}</h2>
    <div v-if="element">
      <div
        v-for="(field, index) in currentSchema"
        :key="index"
        class="mb-4"
      >
        <label class="block text-sm font-medium text-slate-100 mb-1">{{ field.label }}</label>
        <input
          type="text"
          class="border rounded w-full px-3 py-1 text-sm bg-slate-600"
          :value="getByPath(element, field.path)"
          @input="e => setByPath(element, field.path, e.target.value)"
        />
      </div>
    </div>
    <div v-else class="text-gray-500">No element selected.</div>
  </div>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({ element: Object });

const structuralSchemas = {
  Struct: [
    { label: 'Name', path: 'name' },
    { label: 'Visibility', path: 'visibility' },
    { label: 'Literals', path: 'literals' }
  ],
  Variable: [
    { label: 'Variable Name', path: 'name' },
    { label: 'Visibility', path: 'visibility' }
  ]
};



const statementSchemas = {
  AssignmentStatement: [
    { label: 'Left Expression', path: 'expressions.left.base' },
    { label: 'Right Expression', path: 'expressions.right.base' }
  ],
  EmitStatement: [
    { label: 'Event Name', path: 'event.name' },
    { label: 'Argument 1', path: 'event.args[0]' }
  ],
  LoopStatement: [
    { label: 'Loop Variable', path: 'loopVar' },
    { label: 'Condition', path: 'condition.base' }
  ],
  CallStatement: [
    { label: 'Target Function', path: 'target.name' },
    { label: 'Argument 1', path: 'target.args[0]' }
  ],
  ReturnStatement: [
    { label: 'Return Value', path: 'expression.base' }
  ],
  IfStatement: [
    { label: 'Condition', path: 'condition.base' }
  ]
};

const currentSchema = computed(() => {
  if (!props.element || !props.element.type) return [];
  return statementSchemas[props.element.type] || structuralSchemas[props.element.type] || [];
});

function getByPath(obj, path) {
  return path.split('.').reduce((acc, part) => acc?.[part], obj);
}

function setByPath(obj, path, value) {
  const parts = path.split('.');
  const last = parts.pop();
  const target = parts.reduce((acc, part) => acc?.[part], obj);
  if (target && last) target[last] = value;
}
</script>

<style scoped>
input {
  outline: none;
}
</style>
